<link rel="stylesheet" href="../css/header_footer.css">

<footer>
    <div class="footer-content">
        <p>&copy; 2025 Bank Management System. All rights reserved.</p>
    </div>
</footer>

</body>
</html>
