<?php
require_once('../model/db.php'); // Include database connection
// Fetch all customers
$customers = getCustomers();
?>
