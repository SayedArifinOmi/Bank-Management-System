<footer class="footer">
    <p>&copy; <?php echo date("Y"); ?> Bank Management System. All rights reserved.</p>
    <p><a href="#">Privacy Policy</a> | <a href="#">Terms of Service</a></p>
</footer>
</body>
</html>
