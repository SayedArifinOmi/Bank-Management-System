<link rel="stylesheet" href="../CSS/mystyle.css"> 
<footer>
   
    <center><div class="footer-content">
        <h3>CONTACT US</h3>
        <p>📍 iBanking, OLD Dhaka</p>
        <p>☎️ Phone: +880-255665001-6</p>
        <p>✉️ E-mail: ibanking@bb.org.bd</p>
    </div>
    <p class="footer-bottom">Copyright &copy; 2025</p>
</center>
</footer>
