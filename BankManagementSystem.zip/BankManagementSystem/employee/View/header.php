<link rel="stylesheet" href="../CSS/mystyle.css"> 
<header>
    
    <center>
        
        <img src="i.png" alt="iBanking Logo" class="logo" height="70" width="60">
        <div class="header-text">
            <h1>iBanking</h1>
            <p>Empowering Your Financial Journey</p>
        </div>
    </center>
</header>
