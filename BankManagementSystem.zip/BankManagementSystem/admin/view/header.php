<link rel="stylesheet" href="../css/mystyle.css"> 
<header>
    
    <center>
        
        <img src="i.png" alt="iBanking Logo" class="logo" height="40" width="40">
        <div class="header-text">
            <h1>iBanking</h1>
            <p>Empowering Your Financial Journey</p>
        </div>
    </center>
</header>
